

# Homework and PA #1

Part A: Theory and algorithms can be found in hw1.ipynb. Most questions are answered in Markdown, some are written on an ipad and imported in

    - Questions 5 and 6 are done by hand, and can be found in `deliverables/questions_5_and_6.pdf` (they are in reverse order as they appear in homework)


Part B: Programming assignments are found as files in this folder, as directed in the instructions

!!! Note: 
    The submission_autograder.py did not run, but I am confident in the answers provided.
